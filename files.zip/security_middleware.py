from functools import wraps
from typing import Callable, Any
from telegram import Update
from telegram.ext import ContextTypes
from security import SecurityValidator, RequestValidator, ResponseValidator, SecurityMonitor
import logging

logger = logging.getLogger(__name__)

class SecurityMiddleware:
    def __init__(self):
        self.security = SecurityValidator()
        self.request_validator = RequestValidator(self.security)
        self.response_validator = ResponseValidator(self.security)
        self.security_monitor = SecurityMonitor()

    def __call__(self, func: Callable) -> Callable:
        @wraps(func)
        async def wrapped(update: Update, context: ContextTypes.DEFAULT_TYPE, *args: Any, **kwargs: Any) -> Any:
            if not update.effective_user:
                return
                
            user_id = update.effective_user.id
            
            # Check if user is blocked
            if self.security_monitor.is_user_blocked(user_id):
                await update.message.reply_text(
                    "You have been temporarily blocked due to suspicious activity. "
                    "Please try again later."
                )
                return

            try:
                # Validate the incoming message
                if update.message and update.message.text:
                    is_valid, error = self.request_validator.validate_chat_request(
                        user_id=user_id,
                        chat_id=update.effective_chat.id,
                        message=update.message.text,
                        model_id=context.user_data.get('model_id', 'default_model')
                    )
                    
                    if not is_valid:
                        await update.message.reply_text(f"Invalid request: {error}")
                        self.security_monitor.record_failed_attempt(user_id)
                        return

                    # Prepare the message
                    context.user_data['prepared_message'] = self.request_validator.prepare_message(
                        update.message.text
                    )

                # Execute the handler
                result = await func(update, context, *args, **kwargs)

                # Validate the response if it's a string
                if isinstance(result, str):
                    is_valid, sanitized_response = self.response_validator.validate_ai_response(result)
                    if not is_valid:
                        await update.message.reply_text("An error occurred while processing the response.")
                        logger.error(f"Invalid AI response for user {user_id}")
                        return
                    return sanitized_response

                return result

            except Exception as e:
                logger.error(f"Security middleware error for user {user_id}: {str(e)}")
                self.security_monitor.record_failed_attempt(user_id)
                await update.message.reply_text(
                    "An error occurred while processing your request. "
                    "Please try again later."
                )
                raise

        return wrapped