import os
import sqlite3
import aiosqlite
import asyncio
import logging
from datetime import datetime
from typing import Optional, List, Dict, Any, Tuple
from contextlib import asynccontextmanager

logger = logging.getLogger(__name__)

class AsyncDBPool:
    """Connection pool for async database operations"""
    def __init__(self, db_path: str, max_connections: int = 10):
        self.db_path = db_path
        self.max_connections = max_connections
        self._pool = asyncio.Queue(maxsize=max_connections)
        self._active_connections = 0
        self._lock = asyncio.Lock()

    async def _create_connection(self) -> aiosqlite.Connection:
        conn = await aiosqlite.connect(self.db_path)
        await conn.execute("PRAGMA journal_mode=WAL")  # Write-Ahead Logging for better concurrency
        await conn.execute("PRAGMA foreign_keys=ON")
        return conn

    async def initialize(self):
        """Initialize the connection pool"""
        async with self._lock:
            for _ in range(self.max_connections):
                conn = await self._create_connection()
                await self._pool.put(conn)
                self._active_connections += 1

    @asynccontextmanager
    async def acquire(self):
        """Acquire a database connection from the pool"""
        conn = None
        try:
            conn = await self._pool.get()
            yield conn
        finally:
            if conn:
                await self._pool.put(conn)

class AsyncDBHandler:
    def __init__(self, db_path: str):
        self.db_path = db_path
        self._pool: Optional[AsyncDBPool] = None
        
        # Create database directory if it doesn't exist
        os.makedirs(os.path.dirname(self.db_path), exist_ok=True)

    async def initialize(self):
        """Initialize the database handler"""
        self._pool = AsyncDBPool(self.db_path)
        await self._pool.initialize()
        await self.create_tables()
        await self.update_schema()

    async def create_tables(self):
        """Create necessary database tables"""
        async with self._pool.acquire() as conn:
            try:
                await conn.execute('''
                CREATE TABLE IF NOT EXISTS users (
                    id INTEGER PRIMARY KEY,
                    id_chat INTEGER NOT NULL,
                    id_user INTEGER NOT NULL,
                    first_name TEXT,
                    last_name TEXT,
                    username TEXT,
                    register_date DATETIME DEFAULT CURRENT_TIMESTAMP,
                    is_premium INTEGER DEFAULT 0,
                    UNIQUE(id_chat, id_user)
                )
                ''')

                await conn.execute('''
                CREATE TABLE IF NOT EXISTS dialogs (
                    id INTEGER PRIMARY KEY,
                    id_chat INTEGER NOT NULL,
                    id_user INTEGER NOT NULL,
                    number_dialog INTEGER NOT NULL,
                    model TEXT,
                    model_id TEXT,
                    user_ask TEXT,
                    model_answer TEXT,
                    ask_date DATETIME DEFAULT CURRENT_TIMESTAMP,
                    displayed INTEGER DEFAULT 1,
                    FOREIGN KEY (id_chat, id_user) REFERENCES users (id_chat, id_user)
                )
                ''')

                await conn.execute('''
                CREATE TABLE IF NOT EXISTS models (
                    id TEXT PRIMARY KEY,
                    name TEXT NOT NULL,
                    created INTEGER,
                    description TEXT,
                    rus_description TEXT,
                    context_length INTEGER,
                    modality TEXT,
                    tokenizer TEXT,
                    instruct_type TEXT,
                    prompt_price TEXT,
                    completion_price TEXT,
                    image_price TEXT,
                    request_price TEXT,
                    provider_context_length INTEGER,
                    is_moderated INTEGER,
                    is_free INTEGER,
                    top_model INTEGER DEFAULT 0,
                    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
                )
                ''')

                await conn.commit()
                
            except Exception as e:
                logger.error(f"Error creating tables: {e}")
                raise

    async def update_schema(self):
        """Update database schema if necessary"""
        async with self._pool.acquire() as conn:
            try:
                # Check if 'displayed' column exists in 'dialogs' table
                async with conn.execute("PRAGMA table_info(dialogs)") as cursor:
                    columns = [column[1] async for column in cursor]
                
                if 'displayed' not in columns:
                    logger.info("Adding 'displayed' column to 'dialogs' table")
                    await conn.execute("ALTER TABLE dialogs ADD COLUMN displayed INTEGER DEFAULT 1")
                    await conn.commit()
                    
            except Exception as e:
                logger.error(f"Error updating schema: {e}")
                raise

    async def get_user(self, chat_id: int, user_id: int) -> Optional[Dict[str, Any]]:
        """Get user information"""
        async with self._pool.acquire() as conn:
            async with conn.execute(
                "SELECT * FROM users WHERE id_chat = ? AND id_user = ?",
                (chat_id, user_id)
            ) as cursor:
                row = await cursor.fetchone()
                if row:
                    return dict(zip([col[0] for col in cursor.description], row))
                return None

    async def get_models(self, only_free: bool = False, only_top: bool = False) -> List[Dict[str, Any]]:
        """Get available models"""
        query = "SELECT * FROM models"
        conditions = []
        
        if only_free:
            conditions.append("(prompt_price = '0' AND completion_price = '0') OR id LIKE '%:free'")
        if only_top:
            conditions.append("top_model = 1")
            
        if conditions:
            query += " WHERE " + " AND ".join(conditions)
        
        query += " ORDER BY id"
        
        async with self._pool.acquire() as conn:
            async with conn.execute(query) as cursor:
                columns = [col[0] for col in cursor.description]
                return [dict(zip(columns, row)) async for row in cursor]

    async def add_dialog(self, chat_id: int, user_id: int, model_id: str, 
                        user_message: str, model_response: str) -> int:
        """Add a new dialog entry"""
        async with self._pool.acquire() as conn:
            try:
                # Get the next dialog number for this user
                async with conn.execute(
                    """SELECT COALESCE(MAX(number_dialog), 0) + 1 
                       FROM dialogs WHERE id_chat = ? AND id_user = ?""",
                    (chat_id, user_id)
                ) as cursor:
                    number_dialog = await cursor.fetchone()
                    number_dialog = number_dialog[0] if number_dialog else 1

                # Insert the new dialog
                async with conn.execute(
                    """INSERT INTO dialogs 
                       (id_chat, id_user, number_dialog, model_id, user_ask, model_answer)
                       VALUES (?, ?, ?, ?, ?, ?)""",
                    (chat_id, user_id, number_dialog, model_id, user_message, model_response)
                ) as cursor:
                    await conn.commit()
                    return cursor.lastrowid
                    
            except Exception as e:
                logger.error(f"Error adding dialog: {e}")
                raise