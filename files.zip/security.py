import re
import html
import json
import hashlib
import secrets
from typing import Any, Dict, Optional, Union, List
from datetime import datetime
import logging

logger = logging.getLogger(__name__)

class SecurityValidator:
    def __init__(self):
        # Compile regex patterns for validation
        self.patterns = {
            'username': re.compile(r'^[a-zA-Z0-9_]{1,64}$'),
            'model_id': re.compile(r'^[a-zA-Z0-9-_/:]+$'),
            'api_key': re.compile(r'^[A-Za-z0-9-_]{32,}$'),
            'url': re.compile(r'^https?://[\w\-\.]+(:\d+)?(/[\w\-\./]*)?$'),
        }
        
        # Define allowed HTML tags for markdown
        self.allowed_html_tags = {
            'b', 'i', 'code', 'pre', 'a', 'br', 'p',
            'h1', 'h2', 'h3', 'h4', 'ul', 'li'
        }

    def sanitize_input(self, text: str, max_length: int = 4096) -> str:
        """
        Sanitize user input by removing potential XSS and injection attempts
        """
        if not text:
            return ""
            
        # Truncate to maximum length
        text = text[:max_length]
        
        # Escape HTML entities
        text = html.escape(text)
        
        # Remove potential script injection attempts
        text = re.sub(r'javascript:', '', text, flags=re.IGNORECASE)
        text = re.sub(r'data:', '', text, flags=re.IGNORECASE)
        
        # Remove null bytes and other control characters
        text = ''.join(char for char in text if ord(char) >= 32 or char in '\n\r\t')
        
        return text

    def validate_model_id(self, model_id: str) -> bool:
        """Validate model ID format"""
        if not model_id:
            return False
        return bool(self.patterns['model_id'].match(model_id))

    def validate_api_key(self, api_key: str) -> bool:
        """Validate API key format"""
        if not api_key:
            return False
        return bool(self.patterns['api_key'].match(api_key))

    def generate_request_hash(self, user_id: int, timestamp: float) -> str:
        """Generate a unique hash for request verification"""
        data = f"{user_id}:{timestamp}:{secrets.token_hex(16)}"
        return hashlib.sha256(data.encode()).hexdigest()

class RequestValidator:
    def __init__(self, security: SecurityValidator):
        self.security = security
        self._request_cache: Dict[str, Dict[str, Any]] = {}
        
    def validate_chat_request(self, 
                            user_id: int,
                            chat_id: int,
                            message: str,
                            model_id: str) -> tuple[bool, str]:
        """
        Validate a chat request
        Returns (is_valid, error_message)
        """
        # Validate user ID
        if not isinstance(user_id, int) or user_id <= 0:
            return False, "Invalid user ID"
            
        # Validate chat ID
        if not isinstance(chat_id, int) or chat_id <= 0:
            return False, "Invalid chat ID"
            
        # Validate message
        if not message or len(message.strip()) == 0:
            return False, "Message cannot be empty"
            
        if len(message) > 4096:
            return False, "Message too long (max 4096 characters)"
            
        # Validate model ID
        if not self.security.validate_model_id(model_id):
            return False, "Invalid model ID format"
            
        return True, ""

    def prepare_message(self, message: str) -> str:
        """Prepare message for AI model"""
        # Sanitize the input
        message = self.security.sanitize_input(message)
        
        # Remove any potential prompt injection attempts
        message = re.sub(r'<\|.*?\|>', '', message)
        message = re.sub(r'(?i)(system:|assistant:|user:)', '', message)
        
        return message.strip()

class ResponseValidator:
    def __init__(self, security: SecurityValidator):
        self.security = security
        
    def validate_ai_response(self, response: str) -> tuple[bool, str]:
        """
        Validate AI response before sending to user
        Returns (is_valid, sanitized_response)
        """
        if not response:
            return False, ""
            
        # Sanitize the response
        response = self.security.sanitize_input(response)
        
        # Check for potentially harmful content
        if any(pattern in response.lower() for pattern in [
            'javascript:', 'data:', 'vbscript:', 'onclick',
            'onload', 'onerror', '<script', '<iframe'
        ]):
            return False, "Response contained potentially harmful content"
            
        return True, response

class SecurityMonitor:
    def __init__(self):
        self.failed_attempts: Dict[int, List[float]] = {}
        self.blocked_users: Dict[int, float] = {}
        self.suspicious_patterns: Dict[str, int] = {}
        
    def record_failed_attempt(self, user_id: int) -> None:
        """Record a failed attempt for a user"""
        current_time = datetime.utcnow().timestamp()
        
        if user_id not in self.failed_attempts:
            self.failed_attempts[user_id] = []
            
        # Clean up old attempts (older than 1 hour)
        self.failed_attempts[user_id] = [
            t for t in self.failed_attempts[user_id]
            if current_time - t < 3600
        ]
        
        self.failed_attempts[user_id].append(current_time)
        
        # Check if user should be blocked
        if len(self.failed_attempts[user_id]) >= 10:
            self.blocked_users[user_id] = current_time + 3600  # Block for 1 hour
            
    def is_user_blocked(self, user_id: int) -> bool:
        """Check if a user is blocked"""
        current_time = datetime.utcnow().timestamp()
        
        if user_id in self.blocked_users:
            if current_time < self.blocked_users[user_id]:
                return True
            else:
                del self.blocked_users[user_id]
                
        return False
        
    def record_suspicious_pattern(self, pattern: str) -> None:
        """Record a suspicious pattern for monitoring"""
        if pattern not in self.suspicious_patterns:
            self.suspicious_patterns[pattern] = 0
        self.suspicious_patterns[pattern] += 1