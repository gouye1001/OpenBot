from telegram import Update
from telegram.ext import ContextTypes
from ..services.chat_service import ChatService
from ..config import BotConfig

class CommandHandler:
    def __init__(self, chat_service: ChatService, config: BotConfig):
        self.chat_service = chat_service
        self.config = config
        
    async def start(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle the /start command"""
        welcome_message = (
            "👋 Welcome to OpenBot!\n\n"
            "I'm your AI assistant powered by various language models.\n"
            "You can start chatting with me right away or use these commands:\n\n"
            "/help - Show available commands\n"
            "/model - Select AI model\n"
            "/status - Check your usage status"
        )
        await update.message.reply_text(welcome_message)
        
    async def help(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle the /help command"""
        help_text = (
            "Available commands:\n\n"
            "/start - Start the bot\n"
            "/help - Show this help message\n"
            "/model - Select AI model\n"
            "/status - Check your usage status\n"
            "/clear - Clear conversation history\n"
            "/cancel - Cancel current generation\n"
            "/ratelimit - Check rate limit status"
        )
        await update.message.reply_text(help_text)