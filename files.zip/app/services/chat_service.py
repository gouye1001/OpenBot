from typing import List, Optional
import asyncio
from ..models.dialog import Dialog
from ..models.user import User
from ..database.async_db_handler import AsyncDBHandler
from ..security.validators import SecurityValidator
from ..rate_limiter import RateLimiter

class ChatService:
    def __init__(
        self,
        db_handler: AsyncDBHandler,
        security_validator: SecurityValidator,
        rate_limiter: RateLimiter
    ):
        self.db = db_handler
        self.security = security_validator
        self.rate_limiter = rate_limiter
        
    async def process_message(
        self,
        user: User,
        message: str,
        model_id: str,
        update_queue: asyncio.Queue,
        chat_id: int,
        message_id: int,
        cancel_event: asyncio.Event
    ) -> Optional[str]:
        # Validate rate limits
        is_limited, limit_message = await self.rate_limiter.check_rate_limit(
            str(user.id_user),
            user.is_premium
        )
        if is_limited:
            return limit_message
            
        # Validate and sanitize input
        clean_message = self.security.sanitize_input(message)
        if not clean_message:
            return "Invalid message content"
            
        try:
            # Process the message and get AI response
            response = await self.stream_ai_response(
                model_id=model_id,
                user_message=clean_message,
                update_queue=update_queue,
                chat_id=chat_id,
                message_id=message_id,
                cancel_event=cancel_event
            )
            
            # Store dialog in database
            await self.db.add_dialog(
                Dialog(
                    id_chat=chat_id,
                    id_user=user.id_user,
                    model_id=model_id,
                    user_ask=clean_message,
                    model_answer=response,
                    number_dialog=await self.db.get_next_dialog_number(chat_id, user.id_user)
                )
            )
            
            return response
            
        except Exception as e:
            await self.rate_limiter.record_failed_request(str(user.id_user))
            raise