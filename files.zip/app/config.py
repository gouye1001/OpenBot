from dataclasses import dataclass
from typing import Dict, Any
import os
import json
import logging
from pathlib import Path

@dataclass
class BotConfig:
    OPENROUTER_API_KEY: str
    TELEGRAM_TOKEN: str
    SITE_URL: str = "https://github.com/gouye1001/OpenBot"
    SITE_NAME: str = "OpenBot"
    DATABASE_PATH: str = "data/bot.db"
    LOG_LEVEL: str = "INFO"
    MAX_HISTORY: int = 10
    DEFAULT_MODEL: str = "anthropic/claude-3-haiku:free"

class ConfigLoader:
    @staticmethod
    def load_config(config_path: str = "config.json") -> BotConfig:
        if not os.path.exists(config_path):
            raise FileNotFoundError(f"Config file not found: {config_path}")
            
        with open(config_path, 'r') as f:
            config_data = json.load(f)
            
        return BotConfig(**config_data)

class LogConfig:
    @staticmethod
    def setup_logging(level: str = "INFO"):
        logging.basicConfig(
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            level=getattr(logging, level),
            handlers=[
                logging.StreamHandler(),
                logging.FileHandler('logs/bot.log')
            ]
        )