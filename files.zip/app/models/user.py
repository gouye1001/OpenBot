from datetime import datetime
from typing import Optional
from .base import BaseModel

class User(BaseModel):
    def __init__(
        self,
        id_chat: int,
        id_user: int,
        first_name: Optional[str] = None,
        last_name: Optional[str] = None,
        username: Optional[str] = None,
        register_date: Optional[datetime] = None,
        is_premium: bool = False
    ):
        self.id_chat = id_chat
        self.id_user = id_user
        self.first_name = first_name
        self.last_name = last_name
        self.username = username
        self.register_date = register_date or datetime.utcnow()
        self.is_premium = is_premium