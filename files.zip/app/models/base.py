from typing import Any, Dict, Optional
from datetime import datetime

class BaseModel:
    def __init__(self, **kwargs):
        for key, value in kwargs.items():
            setattr(self, key, value)
            
    def to_dict(self) -> Dict[str, Any]:
        return {
            key: value for key, value in self.__dict__.items()
            if not key.startswith('_')
        }
        
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'BaseModel':
        return cls(**data)