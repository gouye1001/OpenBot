from datetime import datetime
from typing import Optional
from .base import BaseModel

class Dialog(BaseModel):
    def __init__(
        self,
        id_chat: int,
        id_user: int,
        number_dialog: int,
        model_id: str,
        user_ask: str,
        model_answer: str,
        ask_date: Optional[datetime] = None,
        displayed: bool = True
    ):
        self.id_chat = id_chat
        self.id_user = id_user
        self.number_dialog = number_dialog
        self.model_id = model_id
        self.user_ask = user_ask
        self.model_answer = model_answer
        self.ask_date = ask_date or datetime.utcnow()
        self.displayed = displayed