from functools import wraps
from typing import Callable, Any, Union
from telegram import Update
from telegram.ext import ContextTypes
from rate_limiter import RateLimiter, RateLimitConfig
import logging

logger = logging.getLogger(__name__)

class RateLimitMiddleware:
    def __init__(self, rate_limiter: RateLimiter):
        self.rate_limiter = rate_limiter

    def __call__(self, func: Callable) -> Callable:
        @wraps(func)
        async def wrapped(update: Update, context: ContextTypes.DEFAULT_TYPE, *args: Any, **kwargs: Any) -> Any:
            if not update.effective_user:
                return await func(update, context, *args, **kwargs)

            user_id = str(update.effective_user.id)
            
            # Check if user is premium (you'll need to implement this check based on your user system)
            is_premium = False
            if context.user_data:
                is_premium = context.user_data.get('is_premium', False)

            # Check rate limit
            is_limited, message = await self.rate_limiter.check_rate_limit(user_id, is_premium)
            if is_limited:
                await update.message.reply_text(message)
                return

            try:
                # Execute the handler
                result = await func(update, context, *args, **kwargs)
                return result
            except Exception as e:
                # Record failed request
                error_message = await self.rate_limiter.record_failed_request(user_id)
                await update.message.reply_text(f"Error: {error_message}")
                logger.error(f"Error in handler: {e}")
                raise

        return wrapped
