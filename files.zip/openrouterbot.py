from security_middleware import SecurityMiddleware
from security import SecurityValidator, RequestValidator, ResponseValidator, SecurityMonitor

# Initialize security components
security_middleware = SecurityMiddleware()

# Apply both rate limiting and security middleware to handlers
@security_middleware()
@RateLimitMiddleware(rate_limiter)
async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    # Access the prepared (sanitized) message
    message = context.user_data.get('prepared_message', '')
    
    # Your existing message handler code here, using the sanitized message
    response = await stream_ai_response_async(
        model_id=context.user_data.get('model_id', 'default_model'),
        user_message=message,
        update_queue=context.update_queue,
        chat_id=update.effective_chat.id,
        message_id=update.message.message_id,
        cancel_event=context.user_data.get('cancel_event', asyncio.Event()),
        context=context
    )
    
    return response