import asyncio
import time
from typing import Dict, Optional, Tuple
from dataclasses import dataclass
from datetime import datetime, timedelta
import logging

logger = logging.getLogger(__name__)

@dataclass
class RateLimitConfig:
    requests_per_minute: int = 20
    requests_per_hour: int = 200
    requests_per_day: int = 1000
    burst_limit: int = 5
    cooldown_minutes: int = 5

class RateLimiter:
    def __init__(self, config: Optional[RateLimitConfig] = None):
        self.config = config or RateLimitConfig()
        self._limits: Dict[str, Dict[str, Dict[str, float]]] = {}
        self._timeouts: Dict[str, float] = {}
        self._locks: Dict[str, asyncio.Lock] = {}
        self._request_history: Dict[str, list] = {}
        
    def _get_user_lock(self, user_id: str) -> asyncio.Lock:
        """Get or create a lock for a specific user"""
        if user_id not in self._locks:
            self._locks[user_id] = asyncio.Lock()
        return self._locks[user_id]

    async def _cleanup_old_requests(self, user_id: str):
        """Clean up old request history"""
        now = time.time()
        if user_id in self._request_history:
            self._request_history[user_id] = [
                timestamp for timestamp in self._request_history[user_id]
                if now - timestamp < 24 * 3600  # Keep last 24 hours
            ]

    def _is_rate_limited(self, user_id: str) -> Tuple[bool, str]:
        """Check if user is rate limited"""
        now = time.time()
        history = self._request_history.get(user_id, [])
        
        # Count requests in different time windows
        minute_requests = sum(1 for t in history if now - t < 60)
        hour_requests = sum(1 for t in history if now - t < 3600)
        day_requests = len(history)
        
        if minute_requests >= self.config.requests_per_minute:
            return True, f"Rate limit exceeded. Please wait a minute. ({minute_requests}/{self.config.requests_per_minute} requests used)"
        
        if hour_requests >= self.config.requests_per_hour:
            return True, f"Hourly limit exceeded. Please try again later. ({hour_requests}/{self.config.requests_per_hour} requests used)"
        
        if day_requests >= self.config.requests_per_day:
            return True, f"Daily limit exceeded. Please try again tomorrow. ({day_requests}/{self.config.requests_per_day} requests used)"
            
        return False, ""

    async def check_rate_limit(self, user_id: str, is_premium: bool = False) -> Tuple[bool, str]:
        """
        Check if a request should be rate limited.
        Returns (is_limited, message).
        """
        async with self._get_user_lock(user_id):
            await self._cleanup_old_requests(user_id)
            
            # Check if user is in timeout
            if user_id in self._timeouts:
                timeout_until = self._timeouts[user_id]
                if time.time() < timeout_until:
                    remaining = int(timeout_until - time.time())
                    return True, f"You are in timeout. Please wait {remaining} seconds."

            # Apply different limits for premium users
            if is_premium:
                self.config.requests_per_minute *= 2
                self.config.requests_per_hour *= 2
                self.config.requests_per_day *= 2

            is_limited, message = self._is_rate_limited(user_id)
            if not is_limited:
                # Record the request
                if user_id not in self._request_history:
                    self._request_history[user_id] = []
                self._request_history[user_id].append(time.time())
                
            return is_limited, message

    async def record_failed_request(self, user_id: str):
        """Record a failed request and apply timeout if necessary"""
        async with self._get_user_lock(user_id):
            now = time.time()
            if user_id not in self._limits:
                self._limits[user_id] = {"failures": [], "timeout_level": 0}
            
            # Clean up old failures
            self._limits[user_id]["failures"] = [
                t for t in self._limits[user_id]["failures"]
                if now - t < 300  # Keep last 5 minutes
            ]
            
            # Record new failure
            self._limits[user_id]["failures"].append(now)
            
            # Check if we need to apply a timeout
            recent_failures = len(self._limits[user_id]["failures"])
            if recent_failures >= self.config.burst_limit:
                timeout_level = self._limits[user_id]["timeout_level"]
                timeout_duration = min(300 * (2 ** timeout_level), 3600)  # Max 1 hour timeout
                
                self._timeouts[user_id] = now + timeout_duration
                self._limits[user_id]["timeout_level"] += 1
                self._limits[user_id]["failures"] = []
                
                return f"Too many failed requests. Timeout for {timeout_duration} seconds."
            
            return "Request failed. Please try again."

    def get_user_stats(self, user_id: str) -> Dict:
        """Get current rate limiting stats for a user"""
        now = time.time()
        history = self._request_history.get(user_id, [])
        
        return {
            "minute_requests": sum(1 for t in history if now - t < 60),
            "hour_requests": sum(1 for t in history if now - t < 3600),
            "day_requests": len(history),
            "is_timeout": user_id in self._timeouts and now < self._timeouts[user_id],
            "timeout_remaining": int(self._timeouts[user_id] - now) if user_id in self._timeouts and now < self._timeouts[user_id] else 0
        }
