import asyncio
import logging
from pathlib import Path
from telegram.ext import Application, MessageHandler, CommandHandler, filters

from app.config import ConfigLoader, LogConfig
from app.services.chat_service import ChatService
from app.database.async_db_handler import AsyncDBHandler
from app.security.validators import SecurityValidator
from app.utils.rate_limiter import RateLimiter
from app.handlers.command_handler import CommandHandler
from app.handlers.message_handler import MessageHandler

logger = logging.getLogger(__name__)

async def main():
    # Load configuration
    config = ConfigLoader.load_config()
    
    # Setup logging
    LogConfig.setup_logging(config.LOG_LEVEL)
    
    # Ensure required directories exist
    Path("data").mkdir(exist_ok=True)
    Path("logs").mkdir(exist_ok=True)
    
    # Initialize components
    db_handler = AsyncDBHandler(config.DATABASE_PATH)
    await db_handler.initialize()
    
    security_validator = SecurityValidator()
    rate_limiter = RateLimiter()
    
    # Initialize services
    chat_service = ChatService(db_handler, security_validator, rate_limiter)
    
    # Initialize handlers
    command_handler = CommandHandler(chat_service, config)
    message_handler = MessageHandler(chat_service, config)
    
    # Initialize bot application
    application = Application.builder().token(config.TELEGRAM_TOKEN).build()
    
    # Add handlers
    application.add_handler(CommandHandler("start", command_handler.start))
    application.add_handler(CommandHandler("help", command_handler.help))
    application.add_handler(CommandHandler("model", message_handler.select_model))
    application.add_handler(CommandHandler("status", message_handler.status))
    application.add_handler(CommandHandler("clear", message_handler.clear))
    application.add_handler(CommandHandler("cancel", message_handler.cancel))
    application.add_handler(CommandHandler("ratelimit", message_handler.rate_limit_status))
    
    # Add message handler for chat
    application.add_handler(MessageHandler(
        filters.TEXT & ~filters.COMMAND,
        message_handler.handle_message
    ))
    
    logger.info("Bot is starting...")
    await application.run_polling()

if __name__ == "__main__":
    asyncio.run(main())